public class Test {
    public static void main(String[] args) {
        Database db = new Database();
        db.open();
        db.view();
    }
}
